function order(packageName) {
  alert("You selected: " + packageName + ". Connect this button to your secure checkout backend.");
}

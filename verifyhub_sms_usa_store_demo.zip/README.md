# VerifyHub Demo

Files:
- index.html: customer-facing website
- admin.html: separate admin portal demo
- style.css: responsive styling
- script.js: demo interactions

Before production:
1. Add secure server-side authentication.
2. Connect a database.
3. Integrate a compliant payment provider.
4. Add lawful number-provider APIs.
5. Never collect, sell, or display passwords, social-media logs, or unauthorized account credentials.
6. Add privacy policy, terms, refund policy, and age-appropriate safeguards.
